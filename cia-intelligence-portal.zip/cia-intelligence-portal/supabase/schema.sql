-- CIA Roleplay Portal schema (Supabase / PostgreSQL)
-- Run in Supabase SQL Editor after creating a project.
-- This is a fictional community roleplay portal, not an official CIA system.

create extension if not exists pgcrypto;

create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('admin','member')),
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  contact text not null check (char_length(contact) between 1 and 80),
  age text,
  role text not null check (char_length(role) between 1 and 40),
  reason text not null check (char_length(reason) between 1 and 800),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '',
  assignee text not null default '',
  priority text not null default 'normal' check (priority in ('low','normal','high')),
  status text not null default 'open' check (status in ('open','completed')),
  created_at timestamptz not null default now()
);

create table if not exists public.access_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function public.is_portal_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

revoke all on function public.is_portal_admin() from public;
grant execute on function public.is_portal_admin() to authenticated;

alter table public.user_roles enable row level security;
alter table public.applications enable row level security;
alter table public.tasks enable row level security;
alter table public.access_codes enable row level security;

-- Only admins can view or manage the role table.
drop policy if exists "Admins read user roles" on public.user_roles;
create policy "Admins read user roles" on public.user_roles
for select to authenticated using (public.is_portal_admin());

drop policy if exists "Admins manage user roles" on public.user_roles;
create policy "Admins manage user roles" on public.user_roles
for all to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

-- Anyone can submit a recruitment application; only admins can read/change/delete.
drop policy if exists "Public can submit applications" on public.applications;
create policy "Public can submit applications" on public.applications
for insert to anon, authenticated
with check (
  status = 'pending'
  and char_length(name) between 1 and 60
  and char_length(contact) between 1 and 80
  and char_length(reason) between 1 and 800
);

drop policy if exists "Admins read applications" on public.applications;
create policy "Admins read applications" on public.applications
for select to authenticated using (public.is_portal_admin());

drop policy if exists "Admins update applications" on public.applications;
create policy "Admins update applications" on public.applications
for update to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

drop policy if exists "Admins delete applications" on public.applications;
create policy "Admins delete applications" on public.applications
for delete to authenticated using (public.is_portal_admin());

-- Tasks and access codes are admin-only.
drop policy if exists "Admins manage tasks" on public.tasks;
create policy "Admins manage tasks" on public.tasks
for all to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

drop policy if exists "Admins manage access codes" on public.access_codes;
create policy "Admins manage access codes" on public.access_codes
for all to authenticated using (public.is_portal_admin()) with check (public.is_portal_admin());

-- To grant an admin after creating their user in Authentication:
-- 1. Copy the user's UUID from Authentication → Users.
-- 2. Run this, replacing UUID:
-- insert into public.user_roles (user_id, role)
-- values ('00000000-0000-0000-0000-000000000000', 'admin')
-- on conflict (user_id) do update set role = 'admin';
--
-- IMPORTANT: Keep the Supabase service_role key private. Never add it to config.js.
